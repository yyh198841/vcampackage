#' Title
#'
#' @param X the covariate data matrix
#' @param TIME the time variable
#' @param Y the response variable
#' @param d the dimension of the covariable
#' @param df the degree of freedom vector of B-Spline. A vector of length (1+2d) corresponds in turn to constant component function, varing-coefficient component functions (d-dimension), and additive component functions (d-dimension).
#'
#' @return MSE: the mean square error
#' @return result.data: the data frame of the estimation results for all component functions
#' @export
VCAMLasso = function(X, TIME, Y, d, df){
  coef_lasso<-function(X,Y){
    cvfit=cv.glmnet(X,Y,family="gaussian",alpha=1,intercept=FALSE)
    lambda1=cvfit$lambda.min;lambda1
    lasso.fit=glmnet(X,Y,family="gaussian",alpha=1,lambda=lambda1,intercept=FALSE)#????????????ģ??
    coef_lasso<-as.vector(coef(lasso.fit))[-1]
    return(coef_lasso)
  }

  N = length(Y)

  #B样条基
  B0 = bSpline(TIME,df=df[1])
  BS<-c();NS<-c()
  for(k in 1:d){
    Bk<-bSpline(TIME,df[k+1]);Nk<-bSpline(X[,k],df[k+1+d])
    BS<-cbind(BS,Bk);NS<-cbind(NS,Nk)
  }

  #----初始值-----
  #phi_ini_l
  L0<-cbind(B0,NS)
  g_ini_lasso<-as.vector(coef_lasso(L0,Y))

  phi_ini_l<-c()
  for(k in 1:d){
    if(k==1){
      a=0;b=a+df[2+d]
    }else{
      a<-sum(df[(d+2):(d+k)]);b<-a+df[d+1+k]
    }
    phi_k_l<-NS[,(a+1):b]%*%g_ini_lasso[(df[1]+a+1):(df[1]+b)]-
      mean(NS[,(a+1):b]%*%g_ini_lasso[(df[1]+a+1):(df[1]+b)])
    phi_ini_l<-cbind(phi_ini_l,phi_k_l)
  }
  #beta0_ini_l;beta_ini_l
  H.l<-c()
  for(k in 1:d){
    if(k==1){
      a=0;b=a+df[2]
    }else{
      a<-sum(df[2:k]);b<-a+df[1+k]
    }
    h.l<-phi_ini_l[,k]*BS[,(a+1):b]
    H.l<-cbind(H.l,h.l)
  }
  L1<-cbind(B0,H.l)
  f_ini_l<-as.vector(coef_lasso(L1,Y)) #估计的系数
  beta0_ini_l<-B0%*%f_ini_l[1:df[1]]
  beta_ini_l<-c()
  for(k in 1:d){
    if(k==1){
      a=0;b=a+df[2]
    }else{
      a<-sum(df[2:k]);b<-a+df[1+k]
    }
    h1.l<-BS[,(a+1):b]%*%f_ini_l[(df[1]+a+1):(df[1]+b)]
    beta_k_l<-h1.l/mean(h1.l)
    beta_ini_l<-cbind(beta_ini_l,beta_k_l)
  }
  #--------算法：内环外环-------
  #设置初始值
  beta0_new_l<-beta0_ini_l;beta_new_l<-beta_ini_l;phi_new_l<-phi_ini_l
  #外环
  epsi1<-1e-3;diff1<-1;iter=0
  MRS.old<-mean((Y-beta0_ini_l-rowSums(beta_ini_l*phi_ini_l))^2)
  while(diff1>1e-3){
    #内环
    for(k in 1:d){
      product = as.data.frame(beta_new_l[,-k]*phi_new_l[,-k])
      R = Y-beta0_new_l-rowSums(product)
      MRSK.old<-mean((R-beta_new_l[,k]*phi_new_l[,k])^2)
      epsi2<-1e-3;diff2<-1
      while(diff2>1e-3 ){
        if(k==1){
          a=0;b=a+df[2]
        }else{
          a<-sum(df[2:k]);b<-a+df[1+k]
        }
        #beta_hat
        h<-phi_new_l[,k]*BS[,(a+1):b]
        f_hat<-coef_lasso(h,R)#参数部分b样条系数
        beta_hat<-(BS[,(a+1):b]%*%f_hat)/mean(BS[,(a+1):b]%*%f_hat)
        #phi_hat
        if(k==1){
          a=0;b=a+df[d+2]
        }else{
          a<-sum(df[(d+2):(d+k)]);b<-a+df[d+1+k]
        }
        h2<-beta_new_l[,k]*NS[,(a+1):b]
        g_hat<-coef_lasso(h2,R)
        phi_hat<-NS[,(a+1):b]%*%g_hat - mean(NS[,(a+1):b]%*%g_hat)
        #MRSK
        alpha<-as.vector(R-beta_hat*phi_hat)
        MRSk.new<-mean(alpha^2)
        diff2<-abs(MRSk.new-MRSK.old)
        #更新
        beta_new_l[,k]<-beta_hat;phi_new_l[,k]<-phi_hat
        MRSK.old<-MRSk.new
        #print(MRSK.old)
      }
    }
    #beta0_hat
    f0_hat_l<-coef_lasso(B0,Y-rowSums(beta_new_l*phi_new_l))
    beta0_hat<-B0%*%f0_hat_l
    #MRS
    alpha<-as.vector(Y-beta0_hat-rowSums(beta_new_l*phi_new_l))
    MRS.new<-mean(alpha^2)
    diff1=abs(MRS.new-MRS.old)
    #更新
    beta0_new_l<-beta0_hat
    MRS.old<-MRS.new
    iter=iter+1
    #print(iter)
  }
  #----结果：MSE-------
  b.l<-c()
  for(k in 1:d){
    a.l<-beta_new_l[,k]*phi_new_l[,k]
    b.l<-cbind(b.l,a.l)
  }
  Y_hat_l<-beta0_new_l+apply(b.l,1,sum)
  MSE.l<-mean(Y-Y_hat_l,na.rm=TRUE)^2
  #----输出-------
  #保存估计结果
  result.data = data.frame(beta0 = beta0_new_l,beta_new_l,phi_new_l)
  name1 = name2 = c()
  for(i in 1:d){
    a <- paste0('beta', i);name1 = c(name1,a)
    b <- paste0('phi', i);name2 = c(name2,b)
  }
  newname = c(name1,name2)
  names(result.data)[2:(2*d+1)]<-newname
  return(list(MSE = MSE.l,
              result.data = result.data))
}
